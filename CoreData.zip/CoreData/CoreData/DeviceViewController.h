//
//  DeviceViewController.h
//  MyStore
//
//  Created by Rina on 27.05.16.
//  Copyright © 2016 MinushinkaInc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DeviceViewController : UITableViewController

@end
