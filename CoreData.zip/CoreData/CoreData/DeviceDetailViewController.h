//
//  DeviceDetailViewController.h
//  MyStore
//
//  Created by Rina on 27.05.16.
//  Copyright © 2016 MinushinkaInc. All rights reserved.
//

#import <UIKit/UIKit.h>
@import CoreData;

@interface DeviceDetailViewController : UIViewController
@property (weak, nonatomic) IBOutlet UITextField *nameTextField;
@property (weak, nonatomic) IBOutlet UITextField *versionTextField;
@property (weak, nonatomic) IBOutlet UITextField *companyTextField;
@property (strong) NSManagedObjectModel *device;
- (IBAction)cancel:(id)sender;
- (IBAction)save:(id)sender;

@end
