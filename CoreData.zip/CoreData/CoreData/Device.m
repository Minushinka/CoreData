//
//  Device.m
//  CoreData
//
//  Created by Rina on 27.05.16.
//  Copyright © 2016 MinushinkaInc. All rights reserved.
//

#import "Device.h"

@implementation Device

// Insert code here to add functionality to your managed object subclass

@end
