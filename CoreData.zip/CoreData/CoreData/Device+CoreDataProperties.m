//
//  Device+CoreDataProperties.m
//  CoreData
//
//  Created by Rina on 27.05.16.
//  Copyright © 2016 MinushinkaInc. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

#import "Device+CoreDataProperties.h"

@implementation Device (CoreDataProperties)

@dynamic company;
@dynamic name;
@dynamic version;

@end
